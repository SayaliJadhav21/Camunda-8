# Camunda 8 Helm Profile: Ingress NGINX for Kind with TLS Certificates

> **Note**  This profile is still a work in progress. For latest progress, please see this [Github Issue](https://github.com/camunda-community-hub/camunda-8-helm-profiles/issues/41)

NOTE: learn more about ingress-kind https://kind.sigs.k8s.o/docs/user/ingress/#ingress-nginx